<!--
SPDX-FileCopyrightText: Copyright 2026 Beijing Xingdongjiyuan Co. Ltd.
SPDX-License-Identifier: MIT
-->
# XHAND1 Pro-U URDF — V1.2

Left- and right-hand robot description assets published by Beijing Xingdongjiyuan Co. Ltd.
The package contains URDF models, STL geometry, and ROS 1 description-package files.

## Contents

| ROS package | URDF | Root link | Links | Joints |
|---|---|---|---:|---:|
| `xhand_left` | `xhand_left/urdf/xhand_left.urdf` | `left_hand_link` | 50 | 49 |
| `xhand_right` | `xhand_right/urdf/xhand_right.urdf` | `right_hand_link` | 50 | 49 |

Each hand declares 20 revolute joints and 29 fixed joints. Each package contains
50 STL files shared by its visual and collision definitions. Units follow the
URDF convention: metres, radians, kilograms, and kg m².

The `urdf/*.csv` files are historical CAD export metadata, not the authoritative
current model. Use the `.urdf` files and their referenced STL files for import.
Local exporter logs and backup files are not included in this distribution.

## Loading

Place both `xhand_left` and `xhand_right` in the source directory of a ROS 1
catkin workspace, build it, and source its environment so `package://` mesh
references can resolve. For a basic model check in an environment with URDF tools:

```sh
check_urdf /path/to/xhand_left/urdf/xhand_left.urdf
check_urdf /path/to/xhand_right/urdf/xhand_right.urdf
```

The supplied launch files have known issues; see [Known issues](docs/KNOWN_ISSUES.md)
before using them. No ROS distribution or NVIDIA simulator version has been
runtime-validated for this distribution. Importing into Isaac Sim or Isaac Lab
requires the target project's normal URDF import and asset-integration process.

## License and attribution

This distribution is licensed under the [MIT License](LICENSE):

**Copyright 2026 Beijing Xingdongjiyuan Co. Ltd.**

The scope includes the supplied URDF files, STL meshes, CSV metadata, ROS package
files, and accompanying documentation. Preserve the MIT copyright and permission
notice when redistributing copies or substantial portions. Machine-readable
SPDX annotations appear in text-file headers and in adjacent `.license` files
for STL and CSV assets; the license text is also in `LICENSES/MIT.txt`.

See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for generation provenance.
This package does not distribute a robot driver, firmware, manufacturing CAD,
photographs, video, logos, or NVIDIA software.
